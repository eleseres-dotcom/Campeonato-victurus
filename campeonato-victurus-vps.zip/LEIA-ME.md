# Campeonato Interno Victurus — versão com Postgres na VPS

App único: inscrição aberta ao público, checagem, chaves, horários, edital, e área da
coordenação com senha (pagamentos, geração de chaves e folha para impressão).
Tudo salvo em Postgres, sem depender do Claude.

## O que vai na VPS

    /opt/victurus
    ├── docker-compose.yml   banco + api + proxy com HTTPS
    ├── Caddyfile            seu domínio
    ├── .env                 senhas (criar a partir do .env.example)
    ├── backup.sh            backup diário do banco
    ├── api/                 Node + Express + Postgres
    └── public/index.html    o app

## Instalação (Hostinger, Ubuntu 22/24)

1. Contrate a VPS (o plano mais simples, 1 vCPU e 4 GB, dá e sobra) e escolha a
   imagem **Ubuntu 24.04 com Docker**. Se escolher Ubuntu puro:

       apt update && apt install -y docker.io docker-compose-plugin

2. Aponte o domínio para o IP da VPS: registro **A** para o IP, no seu provedor
   de DNS. Sem domínio o HTTPS não funciona; use um subdomínio, por exemplo
   `campeonato.victurus.com.br`.

3. Envie os arquivos para `/opt/victurus` (pelo File Manager da Hostinger, por
   `scp -r . root@SEU_IP:/opt/victurus` ou por git).

4. Configure as senhas:

       cd /opt/victurus
       cp .env.example .env
       nano .env            # troque as três senhas
       openssl rand -hex 32 # use a saída como TOKEN_SEGREDO

5. Coloque o seu domínio na primeira linha do `Caddyfile`.

6. Suba tudo:

       docker compose up -d
       docker compose logs -f api   # conferir se subiu

7. Abra `https://seu-dominio`. Toque em **Entrar** e use a `ADMIN_SENHA`
   para acessar a coordenação.

8. Backup diário:

       crontab -e
       0 3 * * * /opt/victurus/backup.sh

## Pix automático (Asaas ou Mercado Pago)

O aluno escolhe **Pix pelo app** e recebe o QR Code na própria tela. Quando o Pix
cai, o Mercado Pago avisa a API e a inscrição muda sozinha para confirmada, com
forma "Pix", data e valor lançados. Ninguém precisa conferir comprovante.

### Asaas (recomendado, taxa fixa por Pix)

1. Abra a conta em asaas.com (CPF ou CNPJ) e conclua a verificação.
2. No painel: **Integrações → Chave de API**, gere e copie a chave.
3. No `.env`: `PSP=asaas`, cole a chave em `ASAAS_API_KEY`, invente um valor para
   `ASAAS_WEBHOOK_TOKEN` e preencha `URL_BASE`.
4. Ainda no painel: **Integrações → Webhooks → Adicionar**, URL
   `https://seu-dominio/api/webhook/asaas`, evento **Cobranças**, e no campo de
   token repita o mesmo `ASAAS_WEBHOOK_TOKEN`.
5. `docker compose up -d` e teste com R$ 1.

Para testar antes sem dinheiro real, use a conta sandbox do Asaas e troque
`ASAAS_API_URL` para `https://api-sandbox.asaas.com/v3`.

O Asaas pede **CPF do pagador** para emitir o Pix, então esse campo aparece no
formulário quando o Pix está no Asaas. O CPF é usado só para gerar a cobrança e
não fica guardado no banco do campeonato.

### Mercado Pago (alternativa, sem CPF)

Use `PSP=mercadopago` no `.env` e siga:

1. Crie a conta em mercadopago.com.br (pode ser CNPJ da escola).
2. Vá em **Seu negócio → Configurações → Gestão e administração → Credenciais**,
   aba **Credenciais de produção**, e copie o **Access Token**.
3. Coloque no `.env`, em `MP_ACCESS_TOKEN`, e preencha `URL_BASE` com o seu domínio.
4. Ainda no painel, em **Webhooks / Notificações**, cadastre a URL
   `https://seu-dominio/api/webhook/mercadopago` e marque o evento **Pagamentos**.
5. Reinicie: `docker compose up -d`.

Em qualquer um dos dois, faça um teste com R$ 1: mude o valor na aba Evento,
inscreva um atleta de teste, pague e veja se confirma sozinha. Depois volte o
valor para R$ 100 e apague o teste.

Detalhes:

- O valor cobrado é o da aba **Evento**, dentro do app. Trocou ali, troca no Pix.
- O QR vale 1 hora. Passou disso, é só refazer a inscrição.
- Se o aviso do Mercado Pago falhar, a API revisa os Pix pendentes a cada minuto,
  então a confirmação acontece de qualquer jeito.
- Quem prefere pagar em dinheiro escolhe **Direto com o professor**, e aí a
  confirmação continua manual, na aba Pagamentos.
- Taxas: o Asaas cobra valor fixo por Pix recebido, algo em torno de R$ 1, que não
  sobe se a inscrição ficar mais cara. O Mercado Pago cobra percentual, perto de 1%.
  Confira as tabelas atuais antes de decidir.
- O dinheiro cai na conta do Asaas ou do Mercado Pago e você transfere para o
  banco da escola quando quiser.
- Sem chave configurada, a opção de Pix aparece desativada no formulário e o app
  orienta a pagar com o professor.

## Como funciona

- **Público:** vê Início, Inscrição, Atletas, Chaves, Horários e Edital.
  A inscrição grava direto no banco, sempre com status "aguardando pagamento",
  e quem paga por Pix é confirmado automaticamente.
- **Coordenação:** entra com senha e ganha as abas Pagamentos, Imprimir e
  Coordenação. Só ela confirma pagamento, muda status, gera chaves e edita o evento.
- A tela atualiza a cada 5 segundos, então o que o professor confirma aparece
  para todo mundo logo em seguida.

## Segurança

- A senha da coordenação fica só no `.env`, nunca no navegador.
- O token de acesso vale 30 dias e é assinado com `TOKEN_SEGREDO`.
- A rota pública de inscrição tem limite de 40 envios por hora por IP e ignora
  qualquer tentativa de enviar status ou valor pago.
- O Postgres não fica exposto na internet, só dentro do Docker.

## Custos aproximados

- VPS Hostinger: entre R$ 30 e R$ 60 por mês.
- Domínio: em torno de R$ 40 por ano.
- Certificado HTTPS: zero, o Caddy emite sozinho.

## Migrar os dados que já estão no app do Claude

A coordenação pode lançar os poucos atletas à mão, ou me peça que eu gero um
arquivo SQL com os registros atuais para você rodar:

    docker compose exec -T banco psql -U victurus campeonato < dados.sql
