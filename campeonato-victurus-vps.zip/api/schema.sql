-- Banco do 1º Campeonato Interno Victurus
CREATE TABLE IF NOT EXISTS registros (
  colecao     TEXT        NOT NULL,
  id          TEXT        NOT NULL,
  dados       JSONB       NOT NULL DEFAULT '{}'::jsonb,
  criado_em   TIMESTAMPTZ NOT NULL DEFAULT now(),
  alterado_em TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (colecao, id)
);
CREATE INDEX IF NOT EXISTS idx_registros_colecao ON registros (colecao);
