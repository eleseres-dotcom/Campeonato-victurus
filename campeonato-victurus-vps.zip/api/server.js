/* API do Campeonato Interno Victurus — Node + Postgres */
const express = require("express");
const crypto  = require("crypto");
const path    = require("path");
const { Pool } = require("pg");

const PORTA   = process.env.PORT || 3000;
const SENHA   = process.env.ADMIN_SENHA   || "victurus2026";
const SEGREDO = process.env.TOKEN_SEGREDO || crypto.randomBytes(32).toString("hex");
const COLECOES = ["atletas", "chaves", "config"];
const PSP        = (process.env.PSP || "mercadopago").toLowerCase(); // mercadopago | asaas
const MP_TOKEN   = process.env.MP_ACCESS_TOKEN || "";
const ASAAS_KEY  = process.env.ASAAS_API_KEY || "";
const ASAAS_API  = process.env.ASAAS_API_URL || "https://api.asaas.com/v3"; // sandbox: https://api-sandbox.asaas.com/v3
const ASAAS_WEBHOOK_TOKEN = process.env.ASAAS_WEBHOOK_TOKEN || "";
const URL_BASE   = process.env.URL_BASE || "";           // ex.: https://campeonato.victurus.com.br
const MP_API     = "https://api.mercadopago.com";
const pixLigado  = () => (PSP === "asaas" ? !!ASAAS_KEY : !!MP_TOKEN);
const DIAS = 30;

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const app = express();
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "..", "public"), { extensions: ["html"] }));

/* ---------- token simples assinado ---------- */
function gerarToken() {
  const exp = Date.now() + DIAS * 864e5;
  const corpo = "coord." + exp;
  const assin = crypto.createHmac("sha256", SEGREDO).update(corpo).digest("hex");
  return corpo + "." + assin;
}
function tokenValido(t) {
  if (!t) return false;
  const p = t.split(".");
  if (p.length !== 3) return false;
  const corpo = p[0] + "." + p[1];
  const esperado = crypto.createHmac("sha256", SEGREDO).update(corpo).digest("hex");
  if (esperado.length !== p[2].length) return false;
  if (!crypto.timingSafeEqual(Buffer.from(esperado), Buffer.from(p[2]))) return false;
  return Number(p[1]) > Date.now();
}
function admin(req, res, next) {
  const t = (req.headers.authorization || "").replace(/^Bearer /, "");
  if (!tokenValido(t)) return res.status(401).json({ erro: "nao_autorizado" });
  next();
}
const colecaoOk = (c) => COLECOES.includes(c);

/* ---------- Pix pelo Mercado Pago ---------- */
async function mp(rota, opcoes = {}) {
  const r = await fetch(MP_API + rota, {
    ...opcoes,
    headers: {
      "Authorization": "Bearer " + MP_TOKEN,
      "Content-Type": "application/json",
      ...(opcoes.headers || {})
    }
  });
  const corpo = await r.json().catch(() => ({}));
  if (!r.ok) throw Object.assign(new Error("mercadopago"), { status: r.status, corpo });
  return corpo;
}

async function valorInscricao() {
  const { rows } = await pool.query("SELECT dados FROM registros WHERE colecao='config' AND id='evento'");
  return Number(rows[0]?.dados?.valor) || 0;
}

async function criarPix(atletaId, dados, valor) {
  const corpo = {
    transaction_amount: valor,
    description: "Inscrição — 1º Campeonato Interno Victurus — " + dados.nome,
    payment_method_id: "pix",
    external_reference: atletaId,
    date_of_expiration: new Date(Date.now() + 36e5).toISOString(),
    payer: {
      email: dados.email || ("inscricao+" + atletaId.slice(0, 40) + "@victurus.com.br"),
      first_name: String(dados.nome).split(" ")[0]
    },
    ...(URL_BASE ? { notification_url: URL_BASE + "/api/webhook/mercadopago" } : {})
  };
  const p = await mp("/v1/payments", {
    method: "POST",
    headers: { "X-Idempotency-Key": atletaId },
    body: JSON.stringify(corpo)
  });
  const tx = p.point_of_interaction?.transaction_data || {};
  return {
    pagamentoId: String(p.id),
    copiaECola: tx.qr_code || "",
    qrBase64: tx.qr_code_base64 || "",
    expiraEm: p.date_of_expiration || null
  };
}

/* ---------- Pix pelo Asaas ---------- */
async function asaas(rota, opcoes = {}) {
  const r = await fetch(ASAAS_API + rota, {
    ...opcoes,
    headers: {
      "access_token": ASAAS_KEY,
      "Content-Type": "application/json",
      "User-Agent": "campeonato-victurus",
      ...(opcoes.headers || {})
    }
  });
  const corpo = await r.json().catch(() => ({}));
  if (!r.ok) throw Object.assign(new Error("asaas"), { status: r.status, corpo });
  return corpo;
}

async function criarPixAsaas(atletaId, dados, valor) {
  const cpf = String(dados.cpf || "").replace(/\D/g, "");
  if (cpf.length !== 11) throw Object.assign(new Error("cpf"), { corpo: { erro: "cpf_invalido" } });

  const cliente = await asaas("/customers", {
    method: "POST",
    body: JSON.stringify({
      name: dados.responsavel || dados.nome,
      cpfCnpj: cpf,
      mobilePhone: String(dados.whatsapp || "").replace(/\D/g, "") || undefined,
      email: dados.email || undefined,
      externalReference: atletaId,
      notificationDisabled: true
    })
  });

  const hoje = new Date().toISOString().slice(0, 10);
  const cobranca = await asaas("/payments", {
    method: "POST",
    body: JSON.stringify({
      customer: cliente.id,
      billingType: "PIX",
      value: valor,
      dueDate: hoje,
      description: "Inscrição — 1º Campeonato Interno Victurus — " + dados.nome,
      externalReference: atletaId
    })
  });

  const qr = await asaas("/payments/" + cobranca.id + "/pixQrCode");
  return {
    pagamentoId: String(cobranca.id),
    copiaECola: qr.payload || "",
    qrBase64: qr.encodedImage || "",
    expiraEm: qr.expirationDate || null
  };
}

/* ---------- comum aos dois meios ---------- */
async function gerarCobranca(atletaId, dados, valor) {
  return PSP === "asaas" ? criarPixAsaas(atletaId, dados, valor) : criarPix(atletaId, dados, valor);
}

async function marcarPago(atletaId, pagamentoId, valor) {
  await pool.query(
    `UPDATE registros SET dados = dados || $2::jsonb, alterado_em = now()
     WHERE colecao='atletas' AND id=$1 AND dados->>'status' = 'pendente'`,
    [atletaId, {
      status: "confirmado",
      forma: "Pix",
      pagoEm: new Date().toISOString(),
      valorPago: Number(valor) || 0,
      pagamentoId: String(pagamentoId)
    }]
  );
}

async function confirmarPagamentoAsaas(pagamentoId) {
  const p = await asaas("/payments/" + pagamentoId);
  if (!["RECEIVED", "CONFIRMED", "RECEIVED_IN_CASH"].includes(p.status)) return false;
  if (!p.externalReference) return false;
  await marcarPago(p.externalReference, p.id, p.value);
  return true;
}

async function confirmarPagamento(pagamentoId) {
  if (PSP === "asaas") return confirmarPagamentoAsaas(pagamentoId);
  const p = await mp("/v1/payments/" + pagamentoId);
  if (p.status !== "approved") return false;
  if (!p.external_reference) return false;
  await marcarPago(p.external_reference, p.id, p.transaction_amount);
  return true;
}

/* ---------- limite simples de inscrições por IP ---------- */
const janela = new Map();
function limite(req, res, next) {
  const ip = req.ip, agora = Date.now();
  const reg = (janela.get(ip) || []).filter((t) => agora - t < 36e5);
  if (reg.length >= 40) return res.status(429).json({ erro: "muitas_requisicoes" });
  reg.push(agora); janela.set(ip, reg); next();
}

/* ---------- rotas ---------- */
app.post("/api/login", (req, res) => {
  const enviada = String(req.body?.senha || "");
  const a = crypto.createHash("sha256").update(enviada).digest();
  const b = crypto.createHash("sha256").update(SENHA).digest();
  if (!crypto.timingSafeEqual(a, b)) return res.status(401).json({ erro: "senha_invalida" });
  res.json({ token: gerarToken() });
});

app.get("/api/eu", admin, (_req, res) => res.json({ ok: true, papel: "coordenacao" }));

// leitura pública: tudo o que as páginas precisam, de uma vez
app.get("/api/tudo", async (_req, res, next) => {
  try {
    const { rows } = await pool.query(
      "SELECT colecao, id, dados FROM registros WHERE colecao = ANY($1)", [COLECOES]
    );
    const saida = Object.fromEntries(COLECOES.map((c) => [c, []]));
    for (const r of rows) saida[r.colecao].push({ id: r.id, dados: r.dados });
    res.json(saida);
  } catch (e) { next(e); }
});

app.get("/api/:colecao", async (req, res, next) => {
  const { colecao } = req.params;
  if (!colecaoOk(colecao)) return res.status(404).json({ erro: "colecao_invalida" });
  try {
    const { rows } = await pool.query(
      "SELECT id, dados FROM registros WHERE colecao=$1 ORDER BY criado_em", [colecao]
    );
    res.json(rows.map((r) => ({ id: r.id, dados: r.dados })));
  } catch (e) { next(e); }
});

// inscrição do aluno: única rota pública de escrita
app.post("/api/inscricao", limite, async (req, res, next) => {
  try {
    const d = req.body?.dados || {};
    const forma = req.body?.pagamento === "pix" ? "pix" : "professor";
    const senhaEnviada = String(req.body?.senha || "").trim().toLowerCase();
    const quem = req.body?.quem === "professor" ? "professor" : "aluno";
    if (!d.nome || !d.nascimento) return res.status(400).json({ erro: "dados_incompletos" });

    // senha da equipe: exigida só quando quem preenche é o professor
    const cfg = await pool.query("SELECT dados FROM registros WHERE colecao='config' AND id='evento'");
    const linhas = String(cfg.rows[0]?.dados?.senhas || "").split("\n");
    if (quem === "professor") for (const linha of linhas) {
      const [equipe, senha] = linha.split("|").map((x) => (x || "").trim());
      if (equipe && equipe.toLowerCase() === String(d.unidade || "").toLowerCase()) {
        if (senha && senha.toLowerCase() !== senhaEnviada) {
          return res.status(403).json({ erro: "senha_equipe" });
        }
      }
    }

    d.status = "pendente";
    d.repassado = false;
    d.inscritoPor = quem;
    delete d.valorPago; delete d.pagoEm; delete d.forma; delete d.pagamentoId;
    const cpfInformado = d.cpf; delete d.cpf;   // CPF só vai ao meio de pagamento, não fica no banco

    const id = String(d.nome).normalize("NFD").replace(/[\u0300-\u036f]/g, "")
      .replace(/[^A-Za-z0-9]+/g, "-").replace(/^-|-$/g, "").toLowerCase().slice(0, 140)
      + "-" + d.nascimento;

    const jaTem = await pool.query("SELECT 1 FROM registros WHERE colecao='atletas' AND id=$1", [id]);
    if (jaTem.rowCount) return res.status(409).json({ erro: "ja_inscrito" });

    // limite de vagas (padrão 360, ajustável na aba Evento)
    const limite = Number(cfg.rows[0]?.dados?.limite) || 360;
    const total = await pool.query("SELECT count(*)::int AS n FROM registros WHERE colecao='atletas'");
    if (total.rows[0].n >= limite) return res.status(409).json({ erro: "vagas_esgotadas" });

    let pix = null;
    if (forma === "pix") {
      const valor = await valorInscricao();
      if (!pixLigado() || !valor) return res.status(503).json({ erro: "pix_indisponivel" });
      try {
        pix = await gerarCobranca(id, { ...d, cpf: cpfInformado }, valor);
        d.pagamentoId = pix.pagamentoId;
        d.formaEscolhida = "Pix";
      } catch (e) {
        console.error("Pix:", e.corpo || e.message);
        if (e.message === "cpf") return res.status(400).json({ erro: "cpf_invalido" });
        return res.status(502).json({ erro: "pix_falhou" });
      }
    }

    await pool.query(
      `INSERT INTO registros (colecao,id,dados) VALUES ('atletas',$1,$2)
       ON CONFLICT (colecao,id) DO NOTHING`, [id, d]
    );
    res.status(201).json({ id, pix });
  } catch (e) { next(e); }
});

// o aluno acompanha a própria inscrição enquanto paga
app.get("/api/inscricao/:id/status", async (req, res, next) => {
  try {
    const { rows } = await pool.query(
      "SELECT dados FROM registros WHERE colecao='atletas' AND id=$1", [req.params.id]
    );
    if (!rows.length) return res.status(404).json({ erro: "nao_encontrado" });
    res.json({ status: rows[0].dados.status || "pendente" });
  } catch (e) { next(e); }
});

// aviso do Mercado Pago quando o Pix cai
app.post("/api/webhook/mercadopago", async (req, res) => {
  res.status(200).end();  // responde rápido, o resto segue em segundo plano
  try {
    const tipo = req.body?.type || req.query?.type;
    const pagamentoId = req.body?.data?.id || req.query?.["data.id"];
    if (tipo === "payment" && pagamentoId) await confirmarPagamento(pagamentoId);
  } catch (e) { console.error("webhook:", e.corpo || e.message); }
});

// aviso do Asaas quando o Pix cai
app.post("/api/webhook/asaas", async (req, res) => {
  if (ASAAS_WEBHOOK_TOKEN && req.headers["asaas-access-token"] !== ASAAS_WEBHOOK_TOKEN) {
    return res.status(401).end();
  }
  res.status(200).end();
  try {
    const evento = req.body?.event;
    const pg = req.body?.payment;
    if (!pg) return;
    if (["PAYMENT_RECEIVED", "PAYMENT_CONFIRMED"].includes(evento) && pg.externalReference) {
      await marcarPago(pg.externalReference, pg.id, pg.value);
    }
  } catch (e) { console.error("webhook asaas:", e.message); }
});

// informa ao app se o Pix está disponível
app.get("/api/pix-ativo", (_req, res) => res.json({ ativo: pixLigado(), psp: PSP, exigeCpf: PSP === "asaas" }));

// vagas restantes, para a página mostrar sem precisar da lista inteira
app.get("/api/vagas", async (_req, res, next) => {
  try {
    const cfg = await pool.query("SELECT dados FROM registros WHERE colecao='config' AND id='evento'");
    const limite = Number(cfg.rows[0]?.dados?.limite) || 360;
    const total = await pool.query("SELECT count(*)::int AS n FROM registros WHERE colecao='atletas'");
    res.json({ limite, usadas: total.rows[0].n, livres: Math.max(0, limite - total.rows[0].n) });
  } catch (e) { next(e); }
});

// rede de segurança: a cada minuto revisa os Pix ainda pendentes
setInterval(async () => {
  if (!pixLigado()) return;
  try {
    const { rows } = await pool.query(
      `SELECT dados->>'pagamentoId' AS pid FROM registros
       WHERE colecao='atletas' AND dados->>'status'='pendente'
         AND dados ? 'pagamentoId' AND alterado_em > now() - interval '3 days' LIMIT 40`
    );
    for (const r of rows) if (r.pid) await confirmarPagamento(r.pid).catch(() => {});
  } catch (e) { console.error("revisao pix:", e.message); }
}, 60000);

// escrita da coordenação
app.post("/api/:colecao", admin, async (req, res, next) => {
  const { colecao } = req.params;
  if (!colecaoOk(colecao)) return res.status(404).json({ erro: "colecao_invalida" });
  try {
    const id = crypto.randomUUID();
    await pool.query("INSERT INTO registros (colecao,id,dados) VALUES ($1,$2,$3)",
      [colecao, id, req.body?.dados || {}]);
    res.status(201).json({ id });
  } catch (e) { next(e); }
});

app.put("/api/:colecao/:id", admin, async (req, res, next) => {
  const { colecao, id } = req.params;
  if (!colecaoOk(colecao)) return res.status(404).json({ erro: "colecao_invalida" });
  try {
    await pool.query(
      `INSERT INTO registros (colecao,id,dados) VALUES ($1,$2,$3)
       ON CONFLICT (colecao,id) DO UPDATE SET dados=$3, alterado_em=now()`,
      [colecao, id, req.body?.dados || {}]
    );
    res.json({ ok: true });
  } catch (e) { next(e); }
});

app.patch("/api/:colecao/:id", admin, async (req, res, next) => {
  const { colecao, id } = req.params;
  if (!colecaoOk(colecao)) return res.status(404).json({ erro: "colecao_invalida" });
  try {
    const { rowCount } = await pool.query(
      `UPDATE registros SET dados = dados || $3::jsonb, alterado_em=now()
       WHERE colecao=$1 AND id=$2`, [colecao, id, req.body?.dados || {}]
    );
    if (!rowCount) return res.status(404).json({ erro: "nao_encontrado" });
    res.json({ ok: true });
  } catch (e) { next(e); }
});

app.delete("/api/:colecao/:id", admin, async (req, res, next) => {
  const { colecao, id } = req.params;
  if (!colecaoOk(colecao)) return res.status(404).json({ erro: "colecao_invalida" });
  try {
    await pool.query("DELETE FROM registros WHERE colecao=$1 AND id=$2", [colecao, id]);
    res.status(204).end();
  } catch (e) { next(e); }
});

app.use((err, _req, res, _next) => { console.error(err); res.status(500).json({ erro: "erro_interno" }); });

(async () => {
  const fs = require("fs");
  await pool.query(fs.readFileSync(path.join(__dirname, "schema.sql"), "utf8"));
  app.listen(PORTA, () => console.log("API do Campeonato Victurus na porta " + PORTA));
})();
