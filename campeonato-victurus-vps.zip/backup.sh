#!/bin/sh
# Backup diário do banco. Rode: crontab -e  ->  0 3 * * * /opt/victurus/backup.sh
DIR=/opt/victurus/backups
mkdir -p "$DIR"
docker compose -f /opt/victurus/docker-compose.yml exec -T banco \
  pg_dump -U victurus campeonato | gzip > "$DIR/campeonato-$(date +%F).sql.gz"
find "$DIR" -name '*.sql.gz' -mtime +30 -delete
