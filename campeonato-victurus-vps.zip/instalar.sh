#!/bin/bash
# Instalação do app do 1º Campeonato Interno Victurus
set -e
cd "$(dirname "$0")"

echo ""
echo "=== Campeonato Victurus — instalação ==="

DOMINIO_PADRAO="srv1996617.hstgr.cloud"
read -p "Endereço do app [$DOMINIO_PADRAO]: " DOMINIO
DOMINIO=${DOMINIO:-$DOMINIO_PADRAO}

if [ ! -f .env ]; then
  read -s -p "Crie a senha da coordenação: " ADMIN
  echo ""
  cat > .env <<ENV
DOMINIO=$DOMINIO
URL_BASE=https://$DOMINIO
POSTGRES_SENHA=$(openssl rand -hex 16)
TOKEN_SEGREDO=$(openssl rand -hex 32)
ADMIN_SENHA=$ADMIN
PSP=
MP_ACCESS_TOKEN=
ASAAS_API_KEY=
ASAAS_API_URL=https://api.asaas.com/v3
ASAAS_WEBHOOK_TOKEN=$(openssl rand -hex 16)
ENV
  chmod 600 .env
  echo ".env criado."
else
  sed -i "s|^DOMINIO=.*|DOMINIO=$DOMINIO|; s|^URL_BASE=.*|URL_BASE=https://$DOMINIO|" .env
  echo ".env já existia, mantive as senhas."
fi

# firewall: libera só SSH e web
if command -v ufw >/dev/null; then
  ufw allow 22/tcp >/dev/null; ufw allow 80/tcp >/dev/null; ufw allow 443/tcp >/dev/null
  ufw --force enable >/dev/null || true
fi

chmod +x backup.sh
( crontab -l 2>/dev/null | grep -v backup.sh; echo "0 3 * * * $(pwd)/backup.sh" ) | crontab -

docker compose up -d
echo ""
echo "Aguardando o app subir..."
sleep 20
docker compose ps
echo ""
echo "Pronto. Abra: https://$DOMINIO"
echo "Na primeira vez o certificado HTTPS pode levar 1 minuto."
